import 'package:flutter/material.dart';
import 'package:signature/signature.dart';

void main() {
  runApp(EmpleadosApp());
}

class EmpleadosApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gestión de Empleados',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: EmpleadosForm(),
    );
  }
}

class EmpleadosForm extends StatefulWidget {
  @override
  _EmpleadosFormState createState() => _EmpleadosFormState();
}

class _EmpleadosFormState extends State<EmpleadosForm> {
  final _formKey = GlobalKey<FormState>();

  // Controladores para los campos de texto
  final TextEditingController idController = TextEditingController();
  final TextEditingController nombreController = TextEditingController();
  final TextEditingController apellidoController = TextEditingController();
  final TextEditingController cedulaController = TextEditingController();
  final TextEditingController cargoController = TextEditingController();
  final TextEditingController areaController = TextEditingController();

  // Controlador para la firma
  final SignatureController _signatureController = SignatureController(
    penStrokeWidth: 2,
    penColor: Colors.black,
    // backgroundColor: Colors.grey[200]!,
  );

  @override
  void dispose() {
    // Liberar recursos
    idController.dispose();
    nombreController.dispose();
    apellidoController.dispose();
    cedulaController.dispose();
    cargoController.dispose();
    areaController.dispose();
    _signatureController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Formulario de Empleado'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: idController,
                decoration: InputDecoration(labelText: 'ID'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese un ID válido';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: nombreController,
                decoration: InputDecoration(labelText: 'Nombre'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese el nombre';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: apellidoController,
                decoration: InputDecoration(labelText: 'Apellido'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese el apellido';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: cedulaController,
                decoration: InputDecoration(labelText: 'Cédula'),
                keyboardType: TextInputType.number,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese la cédula';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: cargoController,
                decoration: InputDecoration(labelText: 'Cargo'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese el cargo';
                  }
                  return null;
                },
              ),
              TextFormField(
                controller: areaController,
                decoration: InputDecoration(labelText: 'Área'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Ingrese el área';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              Text('Firma:', style: TextStyle(fontWeight: FontWeight.bold)),
              SizedBox(
                height: 150,
                child: Signature(
                  controller: _signatureController,
                  height: 150,
                  backgroundColor: Colors.grey[200]!,
                ),
              ),
              Row(
                children: [
                  ElevatedButton(
                    onPressed: () => _signatureController.clear(),
                    child: Text('Limpiar'),
                  ),
                  SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: () {
                      if (_formKey.currentState!.validate()) {
                        // Guardar datos o realizar acciones
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                              content: Text('Datos guardados correctamente')),
                        );
                      }
                    },
                    child: Text('Guardar'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
